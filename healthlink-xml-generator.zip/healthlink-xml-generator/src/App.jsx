import React, { useState } from 'react';
import PatientInfo from './components/PatientInfo';
import TabNavigation from './components/TabNavigation';
import XmlDisplay from './components/XmlDisplay';
import { generateXrayReferral } from './utils/xmlGenerators';

const patient = {
  name: 'Mary Smith',
  dob: '1956-04-27',
  ppsn: '1234567AB',
  gpId: 'GP345678',
  practice: 'Cork Medical Centre'
};

const tabs = ['X-ray Referral', 'X-ray Result', 'Lab Referral', 'Lab Result'];

export default function App() {
  const [activeTab, setActiveTab] = useState(tabs[0]);
  const [xml, setXml] = useState('');
  const [lastGenerated, setLastGenerated] = useState(null);

  const handleGenerate = () => {
    const newXml = generateXrayReferral(patient);
    setXml(newXml);
    setLastGenerated(new Date().toLocaleString());
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold text-indigo-700 mb-4">HealthLink XML Generator</h1>
      <PatientInfo patient={patient} lastGenerated={lastGenerated} />
      <button onClick={handleGenerate} className="mb-4 px-4 py-2 bg-indigo-600 text-white rounded">
        Generate All Sample Data
      </button>
      <TabNavigation active={activeTab} onChange={setActiveTab} tabs={tabs} />
      <h2 className="text-xl font-semibold mb-2">{activeTab}</h2>
      <button onClick={handleGenerate} className="mb-4 px-4 py-2 bg-blue-600 text-white rounded">
        Generate New {activeTab}
      </button>
      <XmlDisplay xml={xml} />
    </div>
  );
}
