export default function TabNavigation({ active, onChange, tabs }) {
  return (
    <div className="flex space-x-2 bg-indigo-100 rounded-md p-1 mb-4">
      {tabs.map(tab => (
        <button
          key={tab}
          onClick={() => onChange(tab)}
          className={\`px-4 py-2 rounded \${active === tab ? 'bg-indigo-600 text-white' : 'bg-white'}\`}
        >
          {tab}
        </button>
      ))}
    </div>
  );
}
