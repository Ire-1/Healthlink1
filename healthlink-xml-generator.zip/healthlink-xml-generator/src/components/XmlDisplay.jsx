export default function XmlDisplay({ xml }) {
  return (
    <textarea
      readOnly
      value={xml}
      className="w-full h-80 p-3 font-mono border border-gray-300 rounded bg-gray-50"
    />
  );
}
