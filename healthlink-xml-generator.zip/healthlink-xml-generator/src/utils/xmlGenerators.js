export function generateXrayReferral(patient) {
  const now = new Date().toISOString();
  const id = Math.floor(Math.random() * 1000000);
  return `<HealthLinkMessage type="Referral" version="1.0">
  <Header>
    <Sender>
      <GPID>${patient.gpId}</GPID>
      <PracticeName>${patient.practice}</PracticeName>
    </Sender>
    <Recipient>
      <ClinicID>RAD${id}</ClinicID>
      <ClinicName>Beacon Hospital</ClinicName>
    </Recipient>
    <Timestamp>${now}</Timestamp>
    <ReferralID>XRAY-REF-${id}</ReferralID>
  </Header>
  <Patient>
    <Name>${patient.name}</Name>
    <DOB>${patient.dob}</DOB>
    <PPSN>${patient.ppsn}</PPSN>
  </Patient>
</HealthLinkMessage>`;
}
