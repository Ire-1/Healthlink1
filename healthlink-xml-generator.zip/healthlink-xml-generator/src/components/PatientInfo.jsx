export default function PatientInfo({ patient, lastGenerated }) {
  return (
    <div className="bg-white rounded-xl shadow p-4 mb-4 flex justify-between items-start">
      <div>
        <p><strong>Name:</strong> {patient.name}</p>
        <p><strong>PPSN:</strong> {patient.ppsn}</p>
        <p><strong>GP ID:</strong> {patient.gpId}</p>
      </div>
      <div className="text-right">
        <p><strong>DOB:</strong> {patient.dob}</p>
        <p><strong>Practice:</strong> {patient.practice}</p>
        <p><strong>Last Generated:</strong> {lastGenerated || 'N/A'}</p>
      </div>
    </div>
  );
}
